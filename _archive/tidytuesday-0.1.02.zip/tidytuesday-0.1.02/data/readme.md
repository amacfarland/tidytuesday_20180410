# DataSets
Data will be uploaded as a .csv and/or .xlsx on a weekly basis.

Hashtag: #TidyTuesday
